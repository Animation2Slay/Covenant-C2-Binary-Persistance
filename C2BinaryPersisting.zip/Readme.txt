 __                 /                                  
/ _   _ |_ |_ .  _                                     
\__) (- |_ |_ | | )                                    
                                                       
 __                                                    
|_   _  _  _  |                                        
|   |  (- (_| |( \/                                    
                 /                                     
                                                       
 _   _     _                                           
(_) | )   (_|                                          
                                                       
 __                                                    
|_   _ .  _|  _        _  .  _  |_  |_       _  _  |_  
|   |  | (_| (_| \/   | ) | (_) | ) |_   \/ (- (_| | ) 
                 /          _/           /            
---------------------------------------------------------------------------------------
To play the game: 
Run the AssetLoader file as Administrator or Default User
Wait for the loader to finish loading the assets
Run the newly created exe "FNF vs Voxel" file from the ASSETS FOLDER!!
Enjoy your Funky Friday! :D
